# -*- coding: utf-8 -*-
{ 
    'name': 'To-Do Application', 
    'description': 'Administrador de tareas personales To-Do tasks.', 
    'author': 'Luis Bracho', 
    'depends': ['base'], 
    'application': True, 
    'sumary': 'Permite administrar las tareas personales de cada usuario',
    'version': '1.0',
    'category': 'sin categoria',
    'data': ['views/todo_menu.xml',
             'views/todo_view.xml',
            ],
    'installable': True,
    'Auto_install': False,
  
}